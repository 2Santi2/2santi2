module.exports = {
  keywords: ["likes", "like"],
};
